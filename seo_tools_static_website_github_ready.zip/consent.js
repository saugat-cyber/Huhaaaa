// consent.js - cookie consent gating for ad script injection and local storage
(function(){
  const key = 'cookie_consent_ads_v1';
  const consent = localStorage.getItem(key);
  const consentBox = document.getElementById('cookie-consent');
  const acceptBtn = document.getElementById('accept-consent');
  const rejectBtn = document.getElementById('reject-consent');
  const adArea = document.getElementById('ad-area');

  function loadAds(){
    // IMPORTANT: Replace the client with your AdSense publisher id (ca-pub-XXXXXXXXXXXX)
    if(document.getElementById('adsense-script')) return;
    const s = document.createElement('script');
    s.id = 'adsense-script';
    s.async = true;
    s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXX';
    s.crossOrigin = 'anonymous';
    document.head.appendChild(s);

    // Insert an ad slot (responsive)
    const adSlot = document.createElement('ins');
    adSlot.className = 'adsbygoogle';
    adSlot.style.display = 'block';
    adSlot.setAttribute('data-ad-client', 'ca-pub-XXXXXXXXXXXX');
    adSlot.setAttribute('data-ad-slot', '1234567890');
    adSlot.setAttribute('data-ad-format', 'auto');
    adSlot.setAttribute('data-full-width-responsive', 'true');
    adArea.innerHTML = '';
    adArea.appendChild(adSlot);
    try{ (adsbygoogle = window.adsbygoogle || []).push({}); }catch(e){ console.warn('Ads not loaded', e); }
  }

  function showConsent(){
    consentBox.classList.remove('hidden');
  }
  function hideConsent(){
    consentBox.classList.add('hidden');
  }

  if(consent === 'yes'){
    loadAds();
  } else if(consent === 'no'){
    // don't load ads, but show a small note
    adArea.querySelector('.ad-placeholder')?.remove();
    const note = document.createElement('div');
    note.className = 'ad-placeholder';
    note.innerText = 'Ads are disabled by your preference.';
    adArea.appendChild(note);
  } else {
    // show consent modal
    setTimeout(showConsent, 600);
  }

  acceptBtn.addEventListener('click', ()=>{
    localStorage.setItem(key, 'yes');
    hideConsent();
    loadAds();
    alert('Thanks — ads will load.');
  });
  rejectBtn.addEventListener('click', ()=>{
    localStorage.setItem(key, 'no');
    hideConsent();
    alert('You chose not to load ads.');
  });
})();