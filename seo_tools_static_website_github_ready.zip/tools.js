// tools.js - client-side tools for the static site.
// NOTE: For production, implement server-side APIs for AI and plagiarism scanning.
// This file provides lightweight local heuristics and UI glue.

const toolArea = document.getElementById('tool-area');
const toolList = document.getElementById('tool-list');

function renderTool(tool){
  if(tool === 'title') return renderTitleTool();
  if(tool === 'keywords') return renderKeywordTool();
  if(tool === 'meta') return renderMetaTool();
  if(tool === 'plag') return renderPlagTool();
  if(tool === 'read') return renderReadabilityTool();
  return '<div>Select a tool</div>';
}

function clearToolArea(){ toolArea.innerHTML = ''; }

toolList.addEventListener('click', e => {
  const li = e.target.closest('li[data-tool]');
  if(!li) return;
  const tool = li.dataset.tool;
  clearToolArea();
  toolArea.innerHTML = '';
  toolArea.appendChild( renderToolElement(tool) );
});

function renderToolElement(tool){
  const wrapper = document.createElement('div');
  wrapper.innerHTML = renderTool(tool);
  return wrapper;
}

/* ---------- Title Generator ---------- */
function renderTitleTool(){
  return `
    <h3>AI Blog Title Generator (client-side)</h3>
    <p class="muted">Local generator: for real AI results, integrate a server-side LLM (OpenAI).</p>
    <div><input id="title-keyword" placeholder="e.g. sustainable travel" style="width:100%; padding:10px; margin-top:10px; border-radius:8px; border:1px solid #e6edf3" /></div>
    <div style="margin-top:10px;"><select id="title-tone" style="padding:8px; border-radius:8px; border:1px solid #e6edf3"><option>Neutral</option><option>Casual</option><option>Clickbait</option><option>Professional</option></select></div>
    <div style="margin-top:12px"><button id="gen-titles" class="btn">Generate Titles</button></div>
    <div id="title-results" style="margin-top:12px"></div>
  `;
}

// Simple heuristics to produce title variations
function generateTitles(keyword, tone){
  const k = keyword.trim();
  if(!k) return [];
  const base = [
    `${k}: The Ultimate Guide`,
    `10 ${k} Tips You Need to Know`,
    `How to ${k} Like a Pro`,
    `Why ${k} Matters in 2025`,
    `The Beginner's Guide to ${k}`
  ];
  if(tone === 'Clickbait') base.unshift(`You Won't Believe These ${k} Tricks!`);
  if(tone === 'Casual') base.push(`${k} — Easy Tips`);
  if(tone === 'Professional') base.push(`${k} — Best Practices & Strategy`);
  return base;
}

/* ---------- Keyword Idea Tool ---------- */
function renderKeywordTool(){
  return `
    <h3>Keyword Idea Tool</h3>
    <p class="muted">For search volumes and competition, integrate a keyword API server-side.</p>
    <div><input id="kw-seed" placeholder="e.g. email marketing" style="width:100%; padding:10px; margin-top:10px; border-radius:8px; border:1px solid #e6edf3" /></div>
    <div style="margin-top:12px"><button id="gen-kw" class="btn">Find Ideas</button></div>
    <div id="kw-results" style="margin-top:12px"></div>
  `;
}
function generateKeywordIdeas(seed){
  const b = seed.trim();
  if(!b) return [];
  return [
    `${b} tips`,
    `${b} guide`,
    `how to ${b}`,
    `${b} for beginners`,
    `best ${b} tools`,
    `${b} checklist`
  ];
}

/* ---------- Meta Tag Generator ---------- */
function renderMetaTool(){
  return `
    <h3>Meta Tag Generator</h3>
    <div><input id="meta-title" placeholder="Page title" style="width:100%; padding:10px; margin-top:10px; border-radius:8px; border:1px solid #e6edf3" /></div>
    <div><textarea id="meta-desc" placeholder="Short meta description (≤155 chars)" style="width:100%; padding:10px; margin-top:10px; border-radius:8px; border:1px solid #e6edf3"></textarea></div>
    <div style="margin-top:12px"><button id="gen-meta" class="btn">Generate & Copy</button></div>
    <div id="meta-output" style="margin-top:12px"></div>
  `;
}

/* ---------- Plagiarism (placeholder) ---------- */
function renderPlagTool(){
  return `
    <h3>Plagiarism Checker (placeholder)</h3>
    <p class="muted">To run real checks you must integrate a paid plagiarism API server-side (e.g., Unicheck, Copyscape).</p>
    <textarea id="plag-text" rows="8" placeholder="Paste content to check..." style="width:100%; padding:10px; border-radius:8px; border:1px solid #e6edf3"></textarea>
    <div style="margin-top:12px"><button id="run-plag" class="btn">Check (local)</button></div>
    <div id="plag-result" style="margin-top:12px"></div>
  `;
}

/* ---------- Readability ---------- */
function renderReadabilityTool(){
  return `
    <h3>Readability Score</h3>
    <p class="muted">Simple Flesch Reading Ease estimator (client-side).</p>
    <textarea id="read-text" rows="8" placeholder="Paste article or paragraph..." style="width:100%; padding:10px; border-radius:8px; border:1px solid #e6edf3"></textarea>
    <div style="margin-top:12px"><button id="calc-read" class="btn">Calculate</button></div>
    <div id="read-result" style="margin-top:12px"></div>
  `;
}

/* ---------- Helpers ---------- */
function estimateSyllables(text){
  const words = text.toLowerCase().replace(/[^a-z\s]/g,'').split(/\s+/).filter(Boolean);
  let syll = 0;
  for(const w of words){
    let s = w.replace(/(?:[^laeiouy]es|ed|[^laeiouy]e)$/, '');
    s = s.replace(/^y/, '');
    const m = s.match(/[aeiouy]{1,2}/g);
    syll += m ? m.length : 1;
  }
  return syll;
}

function fleschReadingEase(text){
  const t = text.trim();
  if(!t) return null;
  const words = t.split(/\s+/).filter(Boolean).length;
  const sentences = Math.max(1, (t.match(/[.!?]+/g) || []).length);
  const syllables = estimateSyllables(t);
  const ASL = words / sentences;
  const ASW = syllables / words;
  const score = 206.835 - (1.015 * ASL) - (84.6 * ASW);
  return Math.round(score);
}

/* ---------- Event delegation for tool actions ---------- */
document.addEventListener('click', function(e){
  if(e.target && e.target.id === 'gen-titles'){
    const kw = document.getElementById('title-keyword').value;
    const tone = document.getElementById('title-tone').value;
    const res = generateTitles(kw, tone);
    const out = document.getElementById('title-results');
    out.innerHTML = res.map(r=>`<div class="result-row"><div>${r}</div><button class="small-copy" data-text="${encodeURIComponent(r)}">Copy</button></div>`).join('');
  }
  if(e.target && e.target.id === 'gen-kw'){
    const seed = document.getElementById('kw-seed').value;
    const res = generateKeywordIdeas(seed);
    const out = document.getElementById('kw-results');
    out.innerHTML = res.map(r=>`<div class="result-row">${r}</div>`).join('');
  }
  if(e.target && e.target.id === 'gen-meta'){
    const t = document.getElementById('meta-title').value || 'Your page title';
    const d = document.getElementById('meta-desc').value || 'A concise meta description.';
    const tags = `<title>${t}</title>\n<meta name="description" content="${d}" />`;
    navigator.clipboard.writeText(tags);
    document.getElementById('meta-output').innerText = 'Meta tags copied to clipboard.';
  }
  if(e.target && e.target.id === 'run-plag'){
    const sample = document.getElementById('plag-text').value.trim();
    const out = document.getElementById('plag-result');
    if(!sample){ out.innerText = 'Paste text to check.'; return; }
    // Local heuristic: check for exact sentence repeats on the web is NOT possible client-side.
    out.innerHTML = '<div class="warning">Plagiarism scan unavailable (client-only). Integrate a server-side API for real checks.</div>';
  }
  if(e.target && e.target.id === 'calc-read'){
    const t = document.getElementById('read-text').value;
    const sc = fleschReadingEase(t);
    document.getElementById('read-result').innerHTML = sc == null ? 'Enter text.' : `<div>Flesch Reading Ease: <strong>${sc}</strong></div>`;
  }

  if(e.target && e.target.classList.contains('small-copy')){
    const txt = decodeURIComponent(e.target.dataset.text || '');
    navigator.clipboard.writeText(txt);
    e.target.innerText = 'Copied';
    setTimeout(()=> e.target.innerText = 'Copy', 1200);
  }
});

// Initialize with title tool
document.addEventListener('DOMContentLoaded', ()=>{
  const first = document.querySelector('#tool-list li[data-tool="title"]');
  if(first) first.click();
});